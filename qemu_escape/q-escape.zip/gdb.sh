sudo gdb \
-ex "file qemu-system-x86_64" \
-ex "attach $1" \
-ex "b*0x68F547"