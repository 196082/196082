#!/bin/bash
gcc ./exp.c -static -masm=intel -pthread -o ./exp
mv exp ./rootfs
cd rootfs
find . | cpio -o --format=newc > ../rootfs.cpio
cd ..

qemu-system-x86_64 \
-m 512M \
-kernel bzImage \
-initrd rootfs.cpio \
-append 'console=ttyS0 quiet' \
-monitor /dev/null \
-cpu kvm64,+smep,+smap \
-smp cores=1,threads=1 \
-nographic \
-s
