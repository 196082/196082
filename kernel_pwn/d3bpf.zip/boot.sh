#!/bin/bash
gcc exp.c -static -masm=intel -pthread -g -o exp
mv exp ./rootfs
cd rootfs
chmod +x exp
find . | cpio -o --format=newc > ../rootfs.cpio
cd ..

qemu-system-x86_64 \
-m 128M \
-kernel bzImage \
-initrd rootfs.cpio \
-append 'console=ttyS0 kaslr quiet' \
-monitor /dev/null \
-cpu kvm64,+smep,+smap \
-smp cores=1,threads=1 \
-nographic \
-s
