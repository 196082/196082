#!/bin/sh
gcc --static -pthread ./exp.c -masm=intel -o exp
strip ./exp
cp -r rootfs rootfs_tmp
mv exp ./rootfs_tmp
chmod +x rootfs_tmp/init
chmod g-w -R rootfs_tmp/
chmod o-w -R rootfs_tmp/
sudo chown -R root rootfs_tmp/
sudo chgrp -R root rootfs_tmp/
sudo chmod u+s rootfs_tmp/bin/busybox
cd rootfs_tmp
find . | cpio -o --format=newc > ../rootfs.cpio
cd ..
sudo rm -r rootfs_tmp

qemu-system-x86_64 \
    -m 512M \
    -kernel ./bzImage \
    -initrd ./rootfs.cpio \
    -append "root=/dev/ram rw console=ttyS0 oops=panic panic=1 kaslr quiet" \
    -cpu kvm64,+smep \
    -net user -net nic -device e1000 \
    -monitor /dev/null \
    -nographic \
    -s